const canvas = document.getElementById("draw");
const ctx = canvas.getContext("2d", { willReadFrequently: true });
const startBtn = document.getElementById("startBtn");
const nextBtn = document.getElementById("nextBtn");
const clearBtn = document.getElementById("clearBtn");
const timerEl = document.getElementById("timer");
const timerBar = document.getElementById("timerBar");
const scoreEl = document.getElementById("score");
const targetEl = document.getElementById("target");
const aiText = document.getElementById("aiText");
const roundsSelect = document.getElementById("rounds");
const customRounds = document.getElementById("customRounds");
const brushRange = document.getElementById("brushRange");
const colorInput = document.getElementById("color");
const ttsToggle = document.getElementById("ttsToggle");
const verboseToggle = document.getElementById("verboseToggle");

const startOverlay = document.getElementById("startOverlay");
const playBtn = document.getElementById("playBtn");
const settingsBtn = document.getElementById("settingsBtn");
const barTop = document.getElementById("barTop");
const barBottom = document.getElementById("barBottom");
const appMain = document.getElementById("app");
const bgMusic = document.getElementById("bgMusic");
const confirmSfx = document.getElementById("confirmSfx");
const winSfx = document.getElementById("winSfx");
const loseSfx = document.getElementById("loseSfx");
const loseScreen = document.getElementById("loseScreen");
const retryBtn = document.getElementById("retryBtn");
const movingBadge = document.getElementById("movingBadge");

let drawing = false;
let brush = Number(brushRange.value);
let color = colorInput.value;
let rainbowMode = false;
let rainbowHue = 0; // hue in degrees for rainbow strokes
let timer = 20;
let timerInterval = null;
let liveGuessInterval = null;
let roundCount = 0;
let totalRounds = Number(roundsSelect.value);
let gameActive = false;
let conversationHistory = [];
let currentTarget = null;

// simple small pool of targets for "the game wants you to draw"
const TARGETS = ["cat","dog","house","tree","car","bicycle","apple","boat","sun","flower","cup","fish","bird","chair","star","key","moon","mushroom","leaf"];

canvas.width = 512;
canvas.height = 512;
ctx.lineCap = "round";
ctx.lineJoin = "round";
ctx.lineWidth = brush;
ctx.strokeStyle = color;
ctx.fillStyle = "#fff";
ctx.fillRect(0,0,canvas.width,canvas.height);

// drawing handlers
function pointerDown(e){
  drawing = true;
  ctx.beginPath();
  const p = getPos(e);
  ctx.moveTo(p.x, p.y);

  if(gameActive && timer > 0 && !liveGuessInterval){
    startLiveGuesses();
  }
}
function pointerMove(e){
  if(!drawing) return;
  const p = getPos(e);

  // If rainbow mode is active, update strokeStyle dynamically per movement so the stroke cycles through hues.
  if(rainbowMode){
    // increase hue slightly per pointer move to create flowing rainbow along the stroke
    rainbowHue = (rainbowHue + 1.8) % 360;
    ctx.strokeStyle = `hsl(${Math.floor(rainbowHue)},100%,50%)`;
  }

  ctx.lineTo(p.x, p.y);
  ctx.stroke();
}
function pointerUp(){
  drawing = false;
}
function getPos(e){
  const rect = canvas.getBoundingClientRect();
  let clientX, clientY;
  if(e.touches && e.touches[0]){
    clientX = e.touches[0].clientX;
    clientY = e.touches[0].clientY;
  } else {
    clientX = e.clientX;
    clientY = e.clientY;
  }
  const x = ((clientX - rect.left) / rect.width) * canvas.width;
  const y = ((clientY - rect.top) / rect.height) * canvas.height;
  return { x, y };
}

canvas.addEventListener("mousedown", pointerDown);
canvas.addEventListener("mousemove", pointerMove);
canvas.addEventListener("mouseup", pointerUp);
canvas.addEventListener("mouseleave", pointerUp);
canvas.addEventListener("touchstart", pointerDown, {passive:true});
canvas.addEventListener("touchmove", pointerMove, {passive:true});
canvas.addEventListener("touchend", pointerUp);

brushRange.addEventListener("input", e=>{
  brush = Number(e.target.value);
  ctx.lineWidth = brush;
});
colorInput.addEventListener("input", e=>{
  color = e.target.value;
  ctx.strokeStyle = color;
});

// Brush color palette and size presets wiring
function selectSwatch(el){
  document.querySelectorAll(".swatch").forEach(s=>s.classList.remove("selected"));
  el.classList.add("selected");
  const c = el.dataset.color;
  // Rainbow special mode
  if(c === "rainbow"){
    rainbowMode = true;
    // pick a pseudo-random start hue so multiple drawers differ
    rainbowHue = Math.floor(Math.random() * 360);
    // reflect a representative color in the color input (keeps UI consistent)
    colorInput.value = `hsl(${rainbowHue}, 100%, 50%)`;
    ctx.strokeStyle = `hsl(${rainbowHue},100%,50%)`;
  } else {
    rainbowMode = false;
    colorInput.value = c;
    color = c;
    ctx.strokeStyle = color;
  }
}
function selectSizeBtn(el){
  document.querySelectorAll(".sizeBtn").forEach(b=>b.classList.remove("active"));
  el.classList.add("active");
  const s = Number(el.dataset.size);
  brushRange.value = s;
  brush = s;
  ctx.lineWidth = brush;
}

document.addEventListener("DOMContentLoaded", ()=>{
  // attach palette listeners
  document.querySelectorAll(".swatch").forEach(s=>{
    s.addEventListener("click", ()=>selectSwatch(s));
  });
  document.querySelectorAll(".sizeBtn").forEach(b=>{
    b.addEventListener("click", ()=>selectSizeBtn(b));
  });
  // initialize selection to current inputs
  const firstSw = document.querySelector(`.swatch[data-color="${colorInput.value}"]`);
  if(firstSw) firstSw.classList.add("selected"); else document.querySelectorAll(".swatch")[0]?.classList.add("selected");
  const initialSize = document.querySelector(`.sizeBtn[data-size="${brushRange.value}"]`);
  if(initialSize) initialSize.classList.add("active");
});

// Make the in-canvas Start Game button trigger the same start flow as the start menu if overlay still visible
startBtn.addEventListener("click", async (e)=>{
  // If the start overlay is still visible, delegate to the hidden playBtn for the transition
  const play = document.getElementById("playBtn");
  if(play && !startOverlay.classList.contains("hidden")){
    play.click();
    return;
  }
  // otherwise start the game normally
  startGame();
});

clearBtn.addEventListener("click", clearCanvas);

roundsSelect.addEventListener("change", e=>{
  if(e.target.value === "custom") {
    customRounds.classList.remove("hidden");
  } else {
    customRounds.classList.add("hidden");
    totalRounds = Number(e.target.value);
  }
});
customRounds.addEventListener("input", e=>{
  const v = Number(e.target.value) || 1;
  totalRounds = Math.max(1, v);
});

startBtn.addEventListener("click", startGame);
nextBtn.addEventListener("click", nextRound);

// start menu behaviors
playBtn.addEventListener("click", async ()=>{
  // ensure lose overlay is fully hidden when revealing the game UI
  loseScreen.classList.add("hidden");
  loseScreen.style.display = "none";

  // while the start overlay is visible we keep canvas interactions disabled (menu must be clickable)
  canvas.style.pointerEvents = "none";
  canvas.style.zIndex = "-1";

  // click sound for feedback
  confirmSfx.currentTime = 0;
  confirmSfx.play().catch(()=>{});


  // close bars animation (visual transition)
  bgMusic.pause();
  barTop.classList.remove("hidden");
  barBottom.classList.remove("hidden");
  barTop.classList.add("closed");
  barBottom.classList.add("closed");

  // hide the MAIN start menu immediately when the bars close in (so the main menu disappears)
  const mainMenuEl = document.getElementById("mainStartMenu");
  if(mainMenuEl) mainMenuEl.classList.add("hidden");

  // after bars closed, hide overlay and reveal main app UI (but DO NOT auto-start rounds)
  await new Promise(r=>setTimeout(r, 900));

  // hide the epic stacks quickly (they belong only to start overlay)
  document.querySelectorAll(".epic-stack").forEach(el=>el.classList.add("stopped"));

  // hide the start overlay and reveal the main UI — user must press the in-canvas "Start Game" button to begin rounds
  startOverlay.classList.add("hidden");
  startOverlay.style.display = "none";
  appMain.classList.remove("hidden");
  // enforce canvas stacking/pointer state after we change overlay visibility
  enforceCanvasBehindMenu();

  // open bars (reverse) then hide them
  barTop.classList.remove("closed");
  barBottom.classList.remove("closed");
  await new Promise(r=>setTimeout(r, 700));
  barTop.classList.add("hidden");
  barBottom.classList.add("hidden");

  // start background music loop (ambient), but keep rounds manual
  try{ bgMusic.currentTime = 0; bgMusic.play().catch(()=>{}); }catch(e){}
});

settingsBtn.addEventListener("click", ()=>{
  // simple toggle rounds select focus as a 'settings' shortcut
  roundsSelect.focus();
});

retryBtn.addEventListener("click", async ()=>{
  // when retrying, play confirm, restore visuals and audio, then restart
  confirmSfx.currentTime = 0;
  confirmSfx.play().catch(()=>{});
  try{
    // remove shatter visual
    appMain.classList.remove("shatter");
    // restore normal pitch before playing
    bgMusic.playbackRate = 1.0;
    bgMusic.currentTime = 0;
    bgMusic.play().catch(()=>{});
  }catch(e){}
  // show loading bars quickly for transition
  barTop.classList.remove("hidden");
  barBottom.classList.remove("hidden");
  await new Promise(r=>setTimeout(r,30));
  barTop.classList.add("closed");
  barBottom.classList.add("closed");
  await new Promise(r=>setTimeout(r,900));
  // hide lose overlay explicitly
  loseScreen.classList.remove("hidden");
  loseScreen.style.display = "none";
  appMain.classList.remove("hidden");
  // ensure canvas gets correct stacking now that lose overlay is removed
  enforceCanvasBehindMenu();
  barTop.classList.remove("closed");
  barBottom.classList.remove("closed");
  await new Promise(r=>setTimeout(r,700));
  barTop.classList.add("hidden");
  barBottom.classList.add("hidden");
  startGame();
});

function clearCanvas(){
  ctx.clearRect(0,0,canvas.width,canvas.height);
  ctx.fillStyle = "#fff";
  ctx.fillRect(0,0,canvas.width,canvas.height);
}

function pickTarget(){
  return TARGETS[Math.floor(Math.random()*TARGETS.length)];
}

function startGame(){
  if(gameActive) return;
  totalRounds = roundsSelect.value === "custom" ? Math.max(1, Number(customRounds.value)||1) : Number(roundsSelect.value);
  roundCount = 0;
  gameActive = true;
  startBtn.disabled = true;
  nextBtn.disabled = true;
  scoreEl.textContent = `Round: ${roundCount} / ${totalRounds}`;
  conversationHistory = [];
  nextRound();
}

async function nextRound(){
  if(!gameActive) return;
  roundCount++;
  if(roundCount > totalRounds){
    await endGame();
    return;
  }
  scoreEl.textContent = `Round: ${roundCount} / ${totalRounds}`;
  clearCanvas();

  currentTarget = pickTarget();
  targetEl.textContent = `Draw: ${currentTarget}`;
  speak(`Round ${roundCount}. Please draw: ${currentTarget}. You have 20 seconds.`);

  startTimer(20);
  clearBtn.disabled = false;
  nextBtn.disabled = true;
}

async function endGame(){
  gameActive = false;
  startBtn.disabled = false;
  nextBtn.disabled = true;
  timerEl.textContent = "0";
  timerBar.style.width = "0%";
  stopLiveGuesses();
  // show summary - if any round was guessed correctly earlier we might have recorded wins; if none, show lose
  // For simplicity: if last round was guessed correctly (we set lastRoundCorrect), it's a win, else lose.
  if(window.lastRoundCorrect){
    aiText.textContent = "You Win! Good job.";
    try{ bgMusic.pause(); winSfx.currentTime = 0; winSfx.play().catch(()=>{}); }catch(e){}
    speak("You win! Congratulations!");
    // after win SFX ends, resume bg music
    winSfx.onended = ()=>{ try{ bgMusic.currentTime = 0; bgMusic.play().catch(()=>{}); }catch(e){} };
  } else {
    // play lose sfx then show animated lose screen; apply shatter/grey and lower music pitch
    aiText.textContent = "You Lose — final result.";
    try{
      // lower pitch / slower playback
      try{ bgMusic.playbackRate = 0.72; }catch(e){}
      bgMusic.pause();
      loseSfx.currentTime = 0;
      loseSfx.play().catch(()=>{});
    }catch(e){}
    // apply visual shatter (grayscale + subtle scale jitter) before reveal
    appMain.classList.add("shatter");
    // after lose sfx ends, animate to lose overlay
    loseSfx.onended = ()=>{
      // hide main app and show loading bars transition then reveal lose overlay
      appMain.classList.add("hidden");
      barTop.classList.remove("hidden");
      barBottom.classList.remove("hidden");
      setTimeout(()=>{
        barTop.classList.add("closed");
        barBottom.classList.add("closed");
        setTimeout(()=>{
          barTop.classList.add("hidden");
          barBottom.classList.add("hidden");
          loseScreen.classList.remove("hidden");
          loseScreen.style.display = "flex";
          // stop background music entirely for effect
          try{ bgMusic.pause(); }catch(e){}
        },700);
      },200);
    };
    speak("You lose. Try again!");
  }
}

function startTimer(seconds){
  timer = seconds;
  timerEl.textContent = timer;
  updateTimerBar();
  clearInterval(timerInterval);
  timerInterval = setInterval(async ()=>{
    timer--;
    timerEl.textContent = timer;
    updateTimerBar();
    if(timer <= 0){
      clearInterval(timerInterval);
      await onDrawTimeEnd();
    }
  }, 1000);

  startLiveGuesses();
}

function updateTimerBar(){
  if(!timerBar) return;
  const percent = Math.max(0, Math.min(100, (timer / 20) * 100));
  timerBar.style.width = percent + "%";
}

async function onDrawTimeEnd(){
  timerEl.textContent = "0";
  timerBar.style.width = "0%";
  stopLiveGuesses();
  nextBtn.disabled = false;
  const guessedCorrect = await sendImageToAI(false); // final analysis, returns true/false
  window.lastRoundCorrect = guessedCorrect;
}

function speak(text){
  if(!ttsToggle.checked) return;
  try{
    const ut = new SpeechSynthesisUtterance(text);
    const voices = speechSynthesis.getVoices();
    if(voices && voices.length){
      const en = voices.find(v=>v.lang && v.lang.startsWith && v.lang.startsWith("en")) || voices[0];
      if(en) ut.voice = en;
    }
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(ut);
  }catch(e){
    console.warn("TTS failed", e);
  }
}

function captureImageBase64(maxSize = 256){
  const tmp = document.createElement("canvas");
  const scale = Math.min(1, maxSize / canvas.width);
  tmp.width = Math.round(canvas.width * scale);
  tmp.height = Math.round(canvas.height * scale);
  const tctx = tmp.getContext("2d");
  tctx.fillStyle = "#fff";
  tctx.fillRect(0,0,tmp.width,tmp.height);
  tctx.drawImage(canvas, 0, 0, tmp.width, tmp.height);
  return tmp.toDataURL("image/png");
}

async function sendImageToAI(live = true){
  if(!canUseAI()){
    aiText.textContent = live ? "Add an AI API key in Settings to enable standalone guesses." : "Add an AI API key in Settings to enable AI guesses.";
    return false;
  }

  aiText.textContent = live ? "AI is making a quick guess..." : "AI is thinking (final)...";
  if(!live) nextBtn.disabled = true;

  const imgDataUrl = captureImageBase64(256);

  const system = live
    ? `You are a quick-guess assistant. Given a small user's drawing image, provide just 1 best guess with a concise confidence like "cat — 60%: short reason". Keep it brief.`
    : `You are an image-interpretation assistant. You will be given an image of a user's drawing. Reply with a short, prioritized list of up to 3 guesses (most likely first). For each guess include: label, confidence as a percentage, and a 1-2 sentence concise explanation of why. If it looks like nothing, say "I can't tell" with low confidence. Focus on visual cues.`;

  const userPrompt = live
    ? `Quickly analyze the attached drawing and return a one-line best guess with percentage and a very short reason.`
    : `Analyze the attached drawing and return up to 3 guesses with confidence and short explanations.`;

  const messages = [
    { role: "system", content: system },
    { role: "user", content: [{ type: "text", text: userPrompt }, { type: "image_url", image_url: { url: imgDataUrl } }] }
  ];

  try{
    let aiResponse;
    if(hasWebsimAI()){
      const completion = await window.websim.chat.completions.create({ messages });
      aiResponse = completion.content?.trim();
    } else {
      const config = readStandaloneAIConfig();
      let endpoint = config.endpoint;
      while(endpoint.endsWith("/")) endpoint = endpoint.slice(0, -1);
      const url = endpoint.endsWith("/chat/completions") ? endpoint : endpoint + "/chat/completions";
      const headers = { "Content-Type": "application/json" };
      if(config.apiKey) headers.Authorization = "Bearer " + config.apiKey;
      const response = await fetch(url, {
        method: "POST",
        headers,
        body: JSON.stringify({ model: config.model, messages })
      });
      const result = await response.json().catch(()=>null);
      if(!response.ok){
        throw new Error(result?.error?.message || "AI endpoint returned HTTP " + response.status);
      }
      const content = result?.choices?.[0]?.message?.content;
      aiResponse = Array.isArray(content) ? content.map(part=>part.text || "").join(String.fromCharCode(10)).trim() : content?.trim();
    }
    aiResponse = aiResponse || "I couldn't form a guess.";
    if(!live){
      conversationHistory.push({ role: "user", content: [{ type: "text", text: userPrompt }, { type: "image_url", image_url: { url: imgDataUrl } }] });
      conversationHistory.push({ role: "assistant", content: aiResponse });
      conversationHistory = conversationHistory.slice(-6);
    }

    displayAIResponse(aiResponse, imgDataUrl, live);

    // If final, try to detect correctness vs currentTarget
    if(!live){
      const top = extractTopGuess(aiResponse);
      const normalizedTop = top ? top.toLowerCase().trim() : "";
      const normalizedTarget = currentTarget ? currentTarget.toLowerCase().trim() : "";
      const matched = normalizedTop && normalizedTarget && normalizedTop === normalizedTarget;
      return matched;
    } else {
      return false;
    }

  }catch(err){
    console.error(err);
    aiText.textContent = "AI error: " + (err.message || String(err));
    if(!live) speak("I encountered an error while asking the AI.");
    return false;
  } finally {
    if(!live) nextBtn.disabled = false;
  }
}

function displayAIResponse(text, imgDataUrl, live){
  let display = text;
  if(!verboseToggle.checked){
    const lines = text.split(/\r?\n/).map(l=>l.trim()).filter(Boolean);
    if(lines.length){
      display = lines[0];
    }
  }
  aiText.textContent = (live ? "Live: " : "") + display;

  const guess = extractTopGuess(text);
  if(guess){
    if(live){
      speak(`Maybe ${guess}.`);
    } else {
      speak(`I think it is ${guess}.`);
    }
  } else {
    if(!live) speak("I can't tell what this is.");
  }
}

function extractTopGuess(text){
  const lines = text.split(/\r?\n/).map(l=>l.trim()).filter(Boolean);
  if(lines.length===0) return null;
  let first = lines[0];
  first = first.replace(/^\d+[\).\s-]*/, "");
  // try a few patterns
  const m = first.match(/^([^—\-:]+)[—\-:]\s*([\d]{1,3}%)/);
  if(m) return m[1].trim();
  const m2 = first.match(/^([^—\-:]+)[—\-:]/);
  if(m2) return m2[1].trim();
  const m3 = first.match(/^(.+?)\s*\([\d]{1,3}%\)/);
  if(m3) return m3[1].trim();
  const few = first.split(/[,:-–—]/)[0].split(" ").slice(0,3).join(" ");
  return few.trim();
}

function startLiveGuesses(){
  stopLiveGuesses();
  if(!canUseAI()){
    aiText.textContent = "Add an AI API key in Settings to enable standalone guesses.";
    return;
  }
  liveGuessInterval = setInterval(()=>{
    if(timer <= 1){
      stopLiveGuesses();
      return;
    }
    sendImageToAI(true);
  }, 4000);
  sendImageToAI(true);
}

function stopLiveGuesses(){
  if(liveGuessInterval){
    clearInterval(liveGuessInterval);
    liveGuessInterval = null;
  }
}

document.body.addEventListener("touchmove", e=>{ if(drawing) e.preventDefault(); }, {passive:false});

window.speechSynthesis.onvoiceschanged = ()=>{ /* noop to force load */ };

scoreEl.textContent = `Round: ${roundCount} / ${totalRounds}`;

  // ensure lose screen is hidden on cold load and start overlay is visible
 // use explicit style toggles so the lose overlay never flashes unintentionally
 loseScreen.classList.remove("hidden");
 loseScreen.style.display = "none";
 startOverlay.classList.remove("hidden");
 appMain.classList.add("hidden");
 // ensure Daydream font is applied immediately for all text nodes (reinforce)
 document.documentElement.style.fontFamily = "Daydream, Inter, system-ui, -apple-system, 'Segoe UI', Roboto, Arial";

 // Play menu background music immediately when the start overlay is visible (menu)
 try{
   bgMusic.currentTime = 0;
   bgMusic.volume = 0.8;
   bgMusic.loop = true;
   bgMusic.play().catch(()=>{ /* autoplay may be blocked until user interaction; no-op */ });
 }catch(e){ /* ignore play errors */ }
 
 // Helper to enforce canvas is behind overlays and non-interactive while overlays are visible.
 // Make canvas sit below the main UI chrome (controls/topbar/etc) so buttons are always clickable.
 function enforceCanvasBehindMenu(){
   const overlayVisible = !startOverlay.classList.contains("hidden") || !loseScreen.classList.contains("hidden");
   if(overlayVisible){
     // When overlays are visible, disable drawing and push canvas behind everything
     canvas.style.pointerEvents = "none";
     canvas.style.zIndex = "-1";
     canvas.classList.add("behind-overlay");
   } else {
     // When app is active, enable drawing but keep UI chrome above canvas by giving canvas a lower z-index than controls
     canvas.style.pointerEvents = "auto";
     // keep canvas slightly behind UI (controls/topbar have z-index:6 in CSS)
     canvas.style.zIndex = "0";
     canvas.classList.remove("behind-overlay");
     // ensure controls/topbar can always receive pointer events
     document.querySelectorAll(".topbar, .controls, .ai-info, .footer").forEach(el=>{
       if(el) el.style.pointerEvents = "auto";
     });
   }
 }
 // initial enforcement
 enforceCanvasBehindMenu();

 // Host UI helpers (client-side demo for host management)
 // Main Menu (in-game) button to return to the start overlay
 const backToStart = document.getElementById("backToStart");
 if(backToStart){
   backToStart.addEventListener("click", async ()=>{
     // play confirm, pause music, show overlay and hide main app
     confirmSfx.currentTime = 0;
     confirmSfx.play().catch(()=>{});
     try{ bgMusic.pause(); }catch(e){}
     appMain.classList.add("hidden");
     startOverlay.classList.remove("hidden");
     // ensure canvas is behind overlays and not interactive while menu visible
     enforceCanvasBehindMenu();
     // ensure bars visible for a smooth transition
     barTop.classList.remove("hidden");
     barBottom.classList.remove("hidden");
     // small open animation then hide bars
     setTimeout(()=>{
       barTop.classList.add("closed");
       barBottom.classList.add("closed");
       setTimeout(()=>{
         barTop.classList.add("hidden");
         barBottom.classList.add("hidden");
       },700);
     },80);
   });
 }

// initial UI hints - no automatic start or drawing prompt until Play is pressed
aiText.textContent = "Press Play to begin — the AI will guess while you draw.";
targetEl.textContent = "Draw: —";

 // Settings and Credits behavior
const settingsPanel = document.getElementById("settingsPanel");
const creditsPanel = document.getElementById("creditsPanel");
const creditsBtn = document.getElementById("creditsBtn");
const settingsBack = document.getElementById("settingsBack");
const creditsBack = document.getElementById("creditsBack");
const vsyncToggle = document.getElementById("vsyncToggle");
const smoothToggle = document.getElementById("smoothToggle");
const startTtsToggle = document.getElementById("startTtsToggle");
const standaloneAiSettings = document.getElementById("standaloneAiSettings");
const standaloneAiFields = {
  endpoint: document.getElementById("aiEndpoint"),
  model: document.getElementById("aiModel"),
  apiKey: document.getElementById("aiApiKey")
};
const standaloneAiStorageKey = "draw-guess-standalone-ai";

function hasWebsimAI(){
  return typeof window.websim?.chat?.completions?.create === "function";
}

function readStandaloneAIConfig(){
  return {
    endpoint: standaloneAiFields.endpoint?.value.trim() || "",
    model: standaloneAiFields.model?.value.trim() || "",
    apiKey: standaloneAiFields.apiKey?.value.trim() || ""
  };
}

function canUseAI(){
  if(hasWebsimAI()) return true;
  const config = readStandaloneAIConfig();
  return Boolean(config.endpoint && config.model && config.apiKey);
}

function saveStandaloneAIConfig(){
  try{
    localStorage.setItem(standaloneAiStorageKey, JSON.stringify(readStandaloneAIConfig()));
  }catch(error){
    console.warn("Could not save standalone AI settings", error);
  }
}

try{
  const saved = JSON.parse(localStorage.getItem(standaloneAiStorageKey) || "null");
  if(saved){
    if(saved.endpoint) standaloneAiFields.endpoint.value = saved.endpoint;
    if(saved.model) standaloneAiFields.model.value = saved.model;
    if(saved.apiKey) standaloneAiFields.apiKey.value = saved.apiKey;
  }
}catch(error){
  console.warn("Could not load standalone AI settings", error);
}
if(!hasWebsimAI()) standaloneAiSettings.classList.remove("hidden");
Object.values(standaloneAiFields).forEach(field=>field.addEventListener("input", saveStandaloneAIConfig));

// Settings open/close
settingsBtn.addEventListener("click", ()=>{
  document.getElementById("mainStartMenu").classList.add("hidden");
  settingsPanel.classList.remove("hidden");
});
settingsBack.addEventListener("click", ()=>{
  settingsPanel.classList.add("hidden");
  document.getElementById("mainStartMenu").classList.remove("hidden");
});
// Credits open/close
creditsBtn.addEventListener("click", ()=>{
  document.getElementById("mainStartMenu").classList.add("hidden");
  creditsPanel.classList.remove("hidden");
});
creditsBack.addEventListener("click", ()=>{
  creditsPanel.classList.add("hidden");
  document.getElementById("mainStartMenu").classList.remove("hidden");
});

// toggles: update body classes to affect animation behavior and TTS default
function applyAnimationToggles(){
  if(!vsyncToggle.checked){
    document.body.classList.add("vsync-off");
  } else {
    document.body.classList.remove("vsync-off");
  }
  if(!smoothToggle.checked){
    document.body.classList.add("no-smooth");
  } else {
    document.body.classList.remove("no-smooth");
  }
  // TTS toggle on start maps to main page setting toggle
  ttsToggle.checked = startTtsToggle.checked;
}
vsyncToggle.addEventListener("change", applyAnimationToggles);
smoothToggle.addEventListener("change", applyAnimationToggles);
startTtsToggle.addEventListener("change", ()=>{ ttsToggle.checked = startTtsToggle.checked; });

applyAnimationToggles();

window.__ai_draw_capture = () => captureImageBase64();